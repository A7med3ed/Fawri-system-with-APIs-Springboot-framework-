import java.util.Scanner;

public class CreditCard implements Payment{
    Scanner myobj =new Scanner(System.in);
    public void pay(Float amount){
        System.out.println("enter card number: ");
        String num = myobj.nextLine();



    }
}
