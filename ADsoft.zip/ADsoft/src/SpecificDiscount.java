import java.util.Scanner;

public class SpecificDiscount extends Discounts{
   // Discounts d=new OverallDiscount();
    Scanner myObj = new Scanner(System.in);
    protected Float percentage=(float)0 ;
    @Override
    public void applyDiscount(Float per) {

        this.percentage= (float)(per/100);
        s.Dis_arr.add(this);



    }
}
