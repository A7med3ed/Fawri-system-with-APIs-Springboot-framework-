public class Form {
    protected String providerName;
    protected String userName;
    protected String phoneNumber;
    protected String address;
    protected int zipCode;
    protected Float servicePrice;

    protected  String nearest_branch;

//    protected  String cridet_card_code;


}
