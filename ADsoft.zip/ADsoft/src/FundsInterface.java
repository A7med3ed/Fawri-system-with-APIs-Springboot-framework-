public interface FundsInterface {
   static void addFunds(){};
}
