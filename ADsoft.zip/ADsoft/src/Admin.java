public class Admin {
    private String username;
    private String password;

}
