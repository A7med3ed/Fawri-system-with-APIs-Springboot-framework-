public interface Observer {
    public abstract void update(String massage);



}
