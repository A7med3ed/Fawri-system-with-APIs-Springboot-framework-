public abstract class Discounts {

    //String seviceName ;
   // Float servicePrice  ;
   protected Float percentage=(float)0 ;
    ServiceController s=ServiceController.getInstance();
    public abstract void  applyDiscount(Float per);
}
