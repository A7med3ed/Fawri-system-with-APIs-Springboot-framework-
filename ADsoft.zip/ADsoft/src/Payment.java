public interface Payment {
    public default void pay(Float amount){};
}
