public class MobileRecharge extends Service{

   public MobileRecharge get_service(int Type){
      Service_Factory Ser=new Service_creator();
        return Ser.Creator_M(Type);


   }
    @Override
    public Float getServiceprice() {
        return null;
    }

    @Override
    public void dis(Float D) {

    }


}
