public class Donations extends Service{


 public  Donations get_service(int donationType){
       Service_Factory Ser=new Service_creator();
        return Ser.Creator_D(donationType);


   }

    @Override
    public Float getServiceprice() {
        return null;
    }

    @Override
    public void dis(Float D) {

    }


}
