public abstract class Service_Factory {

    abstract Donations  Creator_D(int type);
    abstract MobileRecharge Creator_M(int type);
    abstract Landline Creator_L(int type);
    abstract InternetPaymentService Creator_I(int type);
}
