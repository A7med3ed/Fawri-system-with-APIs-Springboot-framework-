import java.util.Scanner;

public class OverallDiscount extends Discounts{
   // Discounts d=new OverallDiscount();
   Scanner myObj = new Scanner(System.in);

    @Override
    public void applyDiscount(Float per) {
     //   seviceName="All";
      //  percentage=myObj.nextFloat();
       percentage=(float)(per/100);
        s.Dis_arr.add(this);



    }
}
