package project.Model;

import project.Controller.Observers.Observers;
import project.View.Payment.Wallet;

import java.util.ArrayList;


public class User implements Observers {
    public User(String user_name,String email,String password) {
        this.user_name = user_name;
        this.email = email;
        this.password = password;
        wallet.currentCredit= Float.valueOf(0);
    }
    public User() {

    }
    public ArrayList <Operation> operationlist = new ArrayList<Operation>();
    public String user_name;
    public String email;
    public String password;
    public Wallet wallet = new Wallet();
    public String credit_num;




    @Override
    public void update(String massage) {
        System.out.println(massage);

    }



}