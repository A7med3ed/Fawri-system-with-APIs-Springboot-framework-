package project.Model;

public class Form {
    public String providerName;
    public String userName;
    public String phoneNumber;
    public String address;
    public int zipCode;
    public double servicePrice;

    public   String nearest_branch;

//    protected  String cridet_card_code;


}