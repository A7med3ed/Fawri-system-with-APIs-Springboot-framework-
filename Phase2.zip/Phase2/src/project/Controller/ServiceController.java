package project.Controller;

import project.Controller.Services.Service;
import project.Controller.Observers.Subject;
import project.Model.Operation;
import project.Model.User;
import project.View.Payment.Cash;
import project.View.Payment.CreditCard;
import project.Controller.Payment.Payment;
import project.Controller.Services.Donations;
import project.Controller.Services.InternetPaymentService;
import project.Controller.Services.Landline;
import project.Controller.Services.MobileRecharge;

import java.util.ArrayList;
import java.util.Scanner;

public class ServiceController implements Subject {
    Scanner myObj = new Scanner(System.in);

    protected ArrayList<Service> services_arr = new ArrayList<Service>();


//    protected ArrayList<User> arr = new ArrayList<User>();
    protected Payment p;
    //protected int user;
    protected  User user;
    Service service;
    AdminController adminControlleront = AdminController.getInstance();
    private static ServiceController sc;
//    Discounts d1 = new OverallDiscount();
//    Discounts d2 = new SpecificDiscount();
    //UserController userController = UserController.getInstance();

    ServiceController() {
    }

    public static ServiceController getInstance() {
        if (sc == null)
            sc = new ServiceController();
        return sc;
    }
//
//    public boolean find(String email, String password) {
//        for (int x = 0; x < arr.size(); x++) {
//            if (Objects.equals(arr.get(x).password, password) && Objects.equals(arr.get(x).email, email)) {
//                user = x;
//                return true;
//            } else
//                return false;
//
//        }
//        return false;
//    }
//
//
//    public boolean find(String user_name, String email, String password) {
//        for (int x = 0; x < arr.size(); x++) {
//            if (Objects.equals(arr.get(x).email, email) || Objects.equals(arr.get(x).user_name, user_name)) {
//                return false;
//            } else {
//                User u = new User(user_name, email, password);
//                arr.add(u);
//                user = x;
//                return true;
//            }
//        }
//
//        if (arr.size() == 0) {
//            User u = new User(user_name, email, password);
//            arr.add(u);
//            return true;
//        }
//        return false;
//    }


    public void search(String question,int choose,int choosepay) {
//        Operation o;
//        if (question.equals("Vodafone")) {
//            switch (choose) {
//                case 1:
//                    service = new MobileRecharge().get_service(1);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//
//                case 2:
//                    service = new InternetPaymentService().get_service(1);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//            }
//        } else if (question.equals("Etisalat")) {
//            switch (choose) {
//                case 1:
//                    service = new MobileRecharge().get_service(3);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//
//                case 2:
//                    service = new InternetPaymentService().get_service(3);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//            }
//        } else if (question.equals("We")) {
//            switch (choose) {
//                case 1:
//                    service = new MobileRecharge().get_service(2);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//
//                case 2:
//                    service = new InternetPaymentService().get_service(2);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//            }
//        } else if (question.equals("Orange")) {
//            switch (choose) {
//                case 1:
//                    service = new MobileRecharge().get_service(4);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    break;
//
//                case 2:
//                    service = new InternetPaymentService().get_service(4);
//                    service.getinfo();
//                    payment(service.getServiceprice(),choosepay);
//                    o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//                    arr.get(user).operationlist.add(o);
//                    // 12 14
//                    break;
//            }
//        } else if (question.equals("Discounts")) {
//
//            service = new Donations().get_service(choose);
//            service.getinfo();
//            payment(service.getServiceprice(),choosepay);
//            o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//            arr.get(user).operationlist.add(o);
//
//        } else if (question.equals("landline")) {
//
//            service = new Landline().get_service(choose);
//            service.getinfo();
//            payment(service.getServiceprice(),choosepay);
//            o =new Operation(service.getServiceprice(),arr.get(user).user_name,service.getServiceName());
//            arr.get(user).operationlist.add(o);
//
//        }
//

    }


//price string
    public void requestRefund(String name,String price,String code) {
//        Refund R = new Refund(name, price, code, user);
//        adminControlleront.refundArr.add(R);
    }


    public void checkDiscount() {

        for (int x = 0; x <= adminControlleront.Dis_arr.size(); x++) {
            if (adminControlleront.Dis_arr.size() == 0) {
                System.out.println("There is no available discount currently");
                break;
            }
            System.out.println(x + 1);
            System.out.println(adminControlleront.Dis_arr.get(x));
        }

    }


//    public void addFundsWallet(float amount) {
//
//        Funds f = new Funds(user.wallet);
//        f.addFunds(amount);
//    }

    public void chooseService(int chooseSer,int Type,int choose) {

        Operation o;
        switch (chooseSer) {
            case 1:
                service = new MobileRecharge().get_service(Type);
//                d2.applyDiscount(service, adminControlleront.Dis_arr.get(chooseSer - 1));
//                d1.applyDiscount(service, adminControlleront.Dis_arr.get(4));
                service.getinfo();
                service.applyDis(adminControlleront.Dis_arr.get(chooseSer - 1));
                payment(service.getServiceprice(),choose);
                o =new Operation(service.getServiceprice(),user.user_name,service.getServiceName());
                user.operationlist.add(o);
                break;
            case 2:
                service = new InternetPaymentService().get_service(Type);
//                d2.applyDiscount(service, adminControlleront.Dis_arr.get(chooseSer - 1));
//                d1.applyDiscount(service, adminControlleront.Dis_arr.get(4));
                service.getinfo();
                service.applyDis(adminControlleront.Dis_arr.get(chooseSer - 1));
                payment(service.getServiceprice(),choose);
                o =new Operation(service.getServiceprice(),user.user_name,service.getServiceName());
                user.operationlist.add(o);
                break;

            case 3:
                service = new Landline().get_service(Type);
//                d2.applyDiscount(service, adminControlleront.Dis_arr.get(chooseSer));
//                d1.applyDiscount(service, adminControlleront.Dis_arr.get(4));
                service.getinfo();
                service.applyDis(adminControlleront.Dis_arr.get(chooseSer - 1));
                payment(service.getServiceprice(),choose);
                o =new Operation(service.getServiceprice(),user.user_name,service.getServiceName());
                user.operationlist.add(o);
                break;

            case 4:
                service = new Donations().get_service(Type);
//                d2.applyDiscount(service, adminControlleront.Dis_arr.get(chooseSer));
//                d1.applyDiscount(service, adminControlleront.Dis_arr.get(4));
                service.getinfo();
                service.applyDis(adminControlleront.Dis_arr.get(chooseSer - 1));
                payment(service.getServiceprice(),choose);
                o =new Operation(service.getServiceprice(),user.user_name,service.getServiceName());
                user.operationlist.add(o);
                break;


            default:
                System.exit(0);

        }
//        adminControlleront.Dis_arr.set(4,0);
        listOperation();

    }

    public void payment(double amount, int choose) {

        switch (choose) {
            case 1:
                p = user.wallet;
                p.pay(amount);
                notifyAmount();
                break;
            case 2:
                p = new Cash();
                p.pay(amount);
                break;
            case 3:
                p = new CreditCard();
                p.pay(amount);
                break;
        }
    }



    @Override
    public void notifyAmount() {

        user.update(user.wallet.currentCredit + "");
    }

    @Override
    public void notifyRefund() {
//        for (int i = 0; i < adminControlleront.accepted.size(); i++) {
//            if (adminControlleront.accepted.get(i) == user) {
//                arr.get(user).update("Your Refund is Accepted!");
//            }
//
//        }
//        for (int i = 0; i < adminControlleront.refused.size(); i++) {
//            if (adminControlleront.refused.get(i) == user) {
//                arr.get(user).update("Your Refund is Refused!");
//            }
//
//        }
    }
    //Test function
    public void listOperation(){
        for (int i = 0; i < user.operationlist.size(); i++) {
            System.out.println("name");
            System.out.println(user.operationlist.get(i).getUserName());
            System.out.println("service name");
            System.out.println(user.operationlist.get(i).getServiceName());
            System.out.println("id");
            System.out.println(user.operationlist.get(i).getId());
            System.out.println("amount");
            System.out.println(user.operationlist.get(i).getAmount());

        }
    }


}

