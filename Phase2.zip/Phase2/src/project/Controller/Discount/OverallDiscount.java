package project.Controller.Discount;
import project.Controller.Services.Service;
import project.Controller.Services.ServicePay;

import java.util.Scanner;

//public class OverallDiscount extends Discount {
//
//    public OverallDiscount(ServicePay service) {
//        super(service);
//    }
//
//    public double decorate(double price, double dis) {
//        return super.decorate( price,  dis) + decorateWithOverall();
//    }
//
//    private double decorateWithOverall() {
//
//        return  ;
//    }
//}
