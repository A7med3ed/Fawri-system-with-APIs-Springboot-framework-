package project.Controller.Discount;

import project.Controller.Services.ServicePay;


public abstract class Discount implements ServicePay {
    private ServicePay service;


    public Discount(ServicePay service) {
        this.service = service;
    }

    // standard constructors
    @Override
    public double decorate(double price, double dis ) {
        return service.decorate(price, dis);
    }
}
