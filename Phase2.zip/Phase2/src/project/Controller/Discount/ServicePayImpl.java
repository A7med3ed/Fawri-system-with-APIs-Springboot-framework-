package project.Controller.Discount;


import project.Controller.Services.ServicePay;

public class ServicePayImpl implements ServicePay {
    @Override
    public double decorate(double price, double dis) {
            return (price);
        }
}

