package project.Controller.Discount;
import project.Controller.Services.ServicePay;

public class SpecificDiscount extends Discount {
    public SpecificDiscount(ServicePay service) {
        super(service);
    }

    public double decorate(double price, double dis) {
        return super.decorate(price, dis) - decorateWithSpecificDiscount(price,dis);
    }


    private double decorateWithSpecificDiscount(double price, double dis) {

        return dis*price;
    }
}

