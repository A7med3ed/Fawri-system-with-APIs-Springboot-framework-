package project.Controller;

import project.Controller.Payment.Funds;
import project.Model.User;

import java.util.ArrayList;
import java.util.Objects;

public class UserController {
    protected ArrayList<User> arr = new ArrayList<User>();
    //protected int user;
    ServiceController serviceController =ServiceController.getInstance();
    private static UserController uc;
    UserController() {
    }

    public static UserController getInstance() {
        if (uc == null)
            uc = new UserController();
        return uc;
    }
    public boolean find(String email, String password) {
        for (int x = 0; x < arr.size(); x++) {
            if (Objects.equals(arr.get(x).password, password) && Objects.equals(arr.get(x).email, email)) {
                serviceController.user = arr.get(x);
                return true;
            } else
                continue;

        }
        return false;
    }


    public boolean find(String user_name, String email, String password) {
        for (int x = 0; x < arr.size(); x++) {
            if (Objects.equals(arr.get(x).email, email) || Objects.equals(arr.get(x).user_name, user_name)) {
                return false;
            } else {
                User u = new User(user_name, email, password);
                arr.add(u);
                serviceController.user = arr.get(arr.size()-1);
                return true;
            }
        }

        if (arr.size() == 0) {
            User u = new User(user_name, email, password);
            arr.add(u);
            serviceController.user = arr.get(0);
            return true;
        }
        return false;
    }
    public void addFundsWallet(float amount) {

        Funds f = new Funds(serviceController.user.wallet);
        f.addFunds(amount);
    }
}
