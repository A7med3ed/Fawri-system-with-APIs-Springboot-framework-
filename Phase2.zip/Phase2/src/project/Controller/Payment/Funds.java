package project.Controller.Payment;

import project.View.Payment.Wallet;

public class Funds implements FundsInterface{
   //make this class controller, remove wallet, remove println

    Wallet w;
    public Funds(Wallet w){
        this.w=w;
    }
    public void addFunds(Float amount){
        w.c.pay(amount);
        w.currentCredit+=amount;
        System.out.println("succesfull operation");

    }
}
