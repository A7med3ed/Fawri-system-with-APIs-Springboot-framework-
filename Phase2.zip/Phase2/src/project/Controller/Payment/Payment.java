package project.Controller.Payment;

public interface Payment {
    public default void pay(double amount){};
}