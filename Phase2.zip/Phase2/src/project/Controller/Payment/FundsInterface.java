package project.Controller.Payment;

public interface FundsInterface {
   static void addFunds(){};
}
