package project.Controller.Services;

public interface ServicePay {
    double decorate(double price, double dis);
}
