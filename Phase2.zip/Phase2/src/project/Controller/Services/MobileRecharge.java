package project.Controller.Services;

import project.Controller.Factory.Service_Factory;
import project.Controller.Factory.Service_creator;

public class MobileRecharge extends Service {

   public MobileRecharge get_service(int Type){
      Service_Factory Ser=new Service_creator();
        return Ser.Creator_M(Type);
   }
    public double getServiceprice(){
        return obj.servicePrice;
    }





}
