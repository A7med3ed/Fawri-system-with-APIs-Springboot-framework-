package project.Controller.Services;

import project.Controller.Discount.ServicePayImpl;
import project.Controller.Discount.SpecificDiscount;
import project.Model.Form;

public  abstract class Service {
//    public Float discountPrice=(float)0;
//    ServicePayImpl servicePayImp;
//    public double servicePrice;
    public Form obj ;
    public String serviceName="";

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }


    public String getServiceName() {
        return serviceName;
    }

    public void getinfo(){}
    public abstract Service get_service(int Type);
    public void applyDis(double disAmount){
        ServicePay dis = new SpecificDiscount(new ServicePayImpl());
        obj.servicePrice = dis.decorate(obj.servicePrice,disAmount);
    }
    public abstract double getServiceprice();
    // public  abstract void dis (Discounts D);

    //deleted
//    public abstract void dis(Float D);
}
