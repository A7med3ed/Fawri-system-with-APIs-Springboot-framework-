package project.Controller.Services;

import project.Controller.Factory.Service_Factory;
import project.Controller.Factory.Service_creator;

public class InternetPaymentService extends Service {
    public InternetPaymentService get_service(int Type){
        Service_Factory Ser=new Service_creator();
        return Ser.Creator_I(Type);
    }

    @Override
    public double getServiceprice(){

        return obj.servicePrice;
    }



}
