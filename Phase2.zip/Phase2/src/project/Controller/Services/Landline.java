package project.Controller.Services;

import project.Controller.Factory.Service_Factory;
import project.Controller.Factory.Service_creator;

public class Landline extends Service {
    int phoneNum;

    public Landline get_service(int receiptType){
        Service_Factory Ser=new Service_creator();
        return Ser.Creator_L(receiptType);


    }
    @Override
    public double getServiceprice(){
        return obj.servicePrice;
    }


}
