package project.Controller.Services;

import project.Controller.Factory.Service_Factory;
import project.Controller.Factory.Service_creator;

public class Donations extends Service {


 public  Donations get_service(int donationType){
       Service_Factory Ser=new Service_creator();
        return Ser.Creator_D(donationType);


   }

    @Override
    public double getServiceprice(){

        return obj.servicePrice;
    }




}
