package project.Controller.Observers;

public interface Observers {

        public abstract void update(String massage);

}
