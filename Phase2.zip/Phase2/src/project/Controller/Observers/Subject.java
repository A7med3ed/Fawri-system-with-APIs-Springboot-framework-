package project.Controller.Observers;
public interface Subject {
   public abstract void notifyAmount();
  public abstract void notifyRefund();

 // public   abstract void notifyDiscount();




}
