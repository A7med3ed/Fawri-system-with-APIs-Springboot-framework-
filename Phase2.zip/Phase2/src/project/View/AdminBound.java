package project.View;

import project.Controller.AdminController;

import java.util.Scanner;

public class AdminBound {
    AdminController cont = AdminController.getInstance();
    Scanner myObj = new Scanner(System.in);

    public void ChooseServices() {
        while (true) {
            System.out.println("Choose Needed service");
            System.out.println("1- List Refunds");
            System.out.println("2- Add Discount");

            int choose;
            choose = myObj.nextInt();
            switch (choose) {
                case 1:
                    for (int i = 0; i < cont.refundArr.size(); i++) {
                        System.out.println(cont.refundArr.get(i).getServiceName());
                        System.out.println(cont.refundArr.get(i).getServicePrice());
                        System.out.println(cont.refundArr.get(i).getServiceCode());
                        System.out.println("1-Accept");
                        System.out.println("2-Refuse");
                        System.out.println("3-Ignore");
                        int choice = myObj.nextInt();
                        cont.listRefunds(i,choice);
                    }
                    break;
                case 2:
                    cont.addDiscount();
                    break;
                default:
                    System.exit(0);
            }

            System.out.println("would you like to make another service?");
            System.out.println("Choose: ");
            System.out.println("1-Yes");
            System.out.println("2-No");
            int ans = myObj.nextInt();
            if (ans == 2) {
                break;
            }
        }

    }
}
