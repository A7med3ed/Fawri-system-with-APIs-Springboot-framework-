package project.View.Payment;

import project.Controller.Payment.Payment;

public class Cash implements Payment {
    public void pay(double amount){
        System.out.print("paying in cash: ");
        System.out.println(amount);
    }
}
