package project.View.Payment;

import project.Controller.Payment.Payment;
import project.Controller.Payment.WalletController;

public class Wallet implements Payment {
    WalletController walletController = new WalletController();
    public double currentCredit = 0.0;
    public CreditCard c =new CreditCard();
    public void pay(double amount){
        double cc ;
        cc = walletController.compare(currentCredit,amount);
        if(currentCredit == cc){
            System.out.println("not enough credit");
        }
        else if (currentCredit > cc){
            currentCredit = cc;
            System.out.println("successfully payment");
        }
    }
}